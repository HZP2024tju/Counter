#include "matplotlibcpp.h"
#include <vector>
#include <math.h>
int main() {
   // matplotlibcpp::backend("Agg");
   /*
    std::vector<double> x = {0, 1, 2, 3};
    std::vector<double> y = {0, 1, 4, 9};
    std::vector<double> y2 = {1, 5, 6, 8};
    matplotlibcpp::named_plot("test", x, y);
    matplotlibcpp::named_plot("test", x, y2);
    matplotlibcpp::show();
    */
    std::vector<double> x(12);
    std::vector<double> y = {0,1.27,2.16,2.86,3.44,3.87,4.15,4.37,4.51,4.58,4.62,4.64};
    for (int i = 0; i < 12; i++)
    {
        x[i] =i*5;
    }
    
    double res=0;
    for (int i = 0; i < x.size(); i++)
    {
        res+=y[i]-0.124*x[i]+0.565;
    }
    std::cout<<'\n'<<res<<std::endl;
    return 0;
}